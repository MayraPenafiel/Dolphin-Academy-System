/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import modelo.Modelo_Usuario;
import vista.vistaUsuario;
import vista.VistaPrincipal;

/**
 *
 * @author MayraPeñafiel
 */
public class ControlPrincipal {
    
    //Atributos
    private VistaPrincipal vp;

    //Constructores
    public ControlPrincipal() {
    }
    public ControlPrincipal(VistaPrincipal vp) {
        this.vp = vp;
        vp.setVisible(true);
    }
    
    public void iniciControl(){
        vp.getMenuCrudUsuarios().addActionListener(l-> crudUsuarios());
        vp.getJbCrudUsuario().addActionListener(l-> crudUsuarios());
    }
    private void crudUsuarios(){
        Modelo_Usuario m= new Modelo_Usuario();
        vistaUsuario v=new vistaUsuario();
        vp.getJdskprincipal().add(v);
        Control_Usuario c= new Control_Usuario(m,v);
        c.iniciaControl();
    }
}
