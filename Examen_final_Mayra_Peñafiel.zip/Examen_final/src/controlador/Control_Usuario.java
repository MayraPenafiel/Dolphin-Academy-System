/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import conexion.conexionPG;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import modelo.Modelo_Usuario;
import modelo.Usuario;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;
import vista.vistaUsuario;

/**
 *
 * @author Mayra Peñafiel
 */

public class Control_Usuario {
    
    //Atributos
    private Modelo_Usuario modelo;
    private vistaUsuario vista;
    DefaultTableModel tabla = new DefaultTableModel();
    private conexionPG con=new conexionPG();
    
    //Constructores
    public Control_Usuario(Modelo_Usuario modelo, vistaUsuario vista) {
        this.modelo = modelo;
        this.vista = vista;
        //INICIALIZAR ELEMENTOS.
        vista.setTitle("CRUD USUARIOS");
        vista.getLbtitutolo2().setText("Bienvienidos/as Sistema 1.0");
        vista.setVisible(true);
        cargarLista("");
    }
    public Control_Usuario() {
    }
    
     public void iniciaControl(){
        KeyListener kl=new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void keyPressed(KeyEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void keyReleased(KeyEvent e) {
                //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                cargarLista(vista.getJtxtbuscar().getText());
            }
        };
        
        //Controlar Eventos de la Visa Persona
        vista.getJbact().addActionListener(l->cargarLista(""));
        vista.getJbadd().addActionListener(l->abrir_dialogo(1));
        vista.getJbedit().addActionListener(l->abrir_dialogo(2));
        vista.getJbdelete().addActionListener(l->abrir_dialogo(3));
        vista.getJbprintuser().addActionListener(l->imprimirReportes());
        
        //Controlar Eventos Vista Dialogo Ingreso/modificar info
        vista.getJbexaminar().addActionListener(l->examinar_foto());
        vista.getJbguardar().addActionListener(l->guardar_usuario());
        vista.getJbcancelar().addActionListener(l->vista.getJdgEditarcrear().dispose());
        vista.getJbconfirmar2().addActionListener(l-> confirmar());
        vista.getJbcancelardel().addActionListener(l-> vista.getJdgeliminar().dispose());
        //Control Buscar
        vista.getJtxtbuscar().addKeyListener(kl);
    }
     
    //Metodo para Imprimir Reportes
    private void imprimirReportes(){
        conexionPG conpg=new conexionPG();
        try {
            JasperReport jr=(JasperReport) JRLoader.loadObject(getClass().getResource("/vista/reportes/ReportePersona.jasper"));
            //Parametros para el reporte
            Map<String,Object> parametros = new HashMap<String,Object>();
            String aguja=vista.getJtxtbuscar().getText();
            parametros.put("paguja","%"+aguja+"%");
            parametros.put("Titulo de Pagina", "Lista de Personas filtradas por: "+aguja);
            JasperPrint jp=JasperFillManager.fillReport(jr,parametros, conpg.getCon());
            JasperViewer jv= new JasperViewer(jp);
            jv.setVisible(true);
        } catch (JRException ex) {
            Logger.getLogger(Control_Usuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void abrir_dialogo(int origen){
        vista.getJdgEditarcrear().setSize(600,400); 
        vista.getJdgEditarcrear().setLocationRelativeTo(vista); 
        if(origen==1){
           vista.getJdgEditarcrear().setTitle("Nuevo Registro"); 
           limpiar();
           vista.getJdgEditarcrear().setVisible(true);
        }
        if(origen==2){ 
            vista.getJdgEditarcrear().setTitle("Editar Registro");
            limpiar();
            vista.getJdgEditarcrear().setVisible(true);
            modificar_registro();
        }
        vista.getJdgeliminar().setSize(450,300); 
        vista.getJdgeliminar().setLocationRelativeTo(vista); 
        if (origen==3){
            vista.getJdgeliminar().setTitle("Eliminar Registro");
            vista.getJdgeliminar().setVisible(true);
            eliminar_u();
        }
    }
    
    private void cargarLista(String aguja){
    //Carga datos a la vista.
        vista.getJtuser().setDefaultRenderer(Object.class, new ImagenTabla());
        vista.getJtuser().setRowHeight(100);
        DefaultTableCellRenderer ren= new DefaultTableCellRenderer();
        DefaultTableModel tablaMD;
        tablaMD = (DefaultTableModel)vista.getJtuser().getModel();
        tablaMD.setNumRows(0);
        List<Usuario> lista=modelo.listarUsuario(aguja);
        lista.stream().forEach(per->{
            Image img=per.getFoto();
            if(img!=null){
                Image nimg=img.getScaledInstance(100,100,Image.SCALE_SMOOTH);
                ImageIcon icon = new ImageIcon(nimg);
                ren.setIcon(icon);
                tablaMD.addRow( new Object[]{per.getId_usuario(),per.getNombre(),per.getPermisos(),new JLabel(icon)});
            }else{
                tablaMD.addRow( new Object[]{per.getId_usuario(),per.getNombre(),per.getPermisos(),null});
            }
        });
    }
    
    private void examinar_foto(){
        JFileChooser jfc= new JFileChooser();
        jfc.setFileSelectionMode(JFileChooser.FILES_ONLY);
        int estado=jfc.showOpenDialog(null);
        if(estado==JFileChooser.APPROVE_OPTION){
            try {
                Image miImagen = ImageIO.read(jfc.getSelectedFile()).getScaledInstance(
                        vista.getJlbfoto().getWidth(),
                        vista.getJlbfoto().getHeight(),
                        Image.SCALE_DEFAULT);
                Icon icon=new ImageIcon(miImagen);
                vista.getJlbfoto().setIcon(icon);
                vista.getJlbfoto().updateUI();
            } catch (IOException ex) {
                Logger.getLogger(Control_Usuario.class.getName()).log(Level.SEVERE, null, ex);
            }        
        }
    }
    
    private void guardar_usuario(){
        String id=vista.getTxtid().getText();
        String nombre=vista.getTxtnom().getText();
        String pass=vista.getTxtpass().getText();
        String permiso=vista.getJcbxpermiso().getSelectedItem().toString();
        //Obtener Foto del label
        ImageIcon ic=(ImageIcon)vista.getJlbfoto().getIcon();
        Modelo_Usuario u=new Modelo_Usuario();
        u.setId_usuario(id);
        u.setNombre(nombre);
        u.setContrasena(pass);
        u.setPermisos(permiso);
        if (ic!=null){
            u.setFoto(ic.getImage());
        }else{
            u.setFoto(null);
        }
        if("Nuevo Registro".equals(vista.getJdgEditarcrear().getTitle())){
            if(u.grabar()){ 
                //limpiar();
                JOptionPane.showMessageDialog(vista, "Persona Creada Satisfactoriamente");
                vista.getJdgEditarcrear().dispose();
            }else{
                JOptionPane.showMessageDialog(vista, "Error");
            }
            limpiar();
        }   
        if("Editar Registro".equals(vista.getJdgEditarcrear().getTitle())){
            if(u.modificar()){
                //limpiar();
                JOptionPane.showMessageDialog(vista, "Persona Modificada Satisfactoriamente");
                vista.getJdgEditarcrear().dispose();
            }else{
                JOptionPane.showMessageDialog(vista, "Error");
            }  
            limpiar();
        }   
    }
    
    private void modificar_registro(){
        int se=vista.getJtuser().getSelectedRow();
        if (se>=0){
            cargarLista("");
            List<Usuario> lista=modelo.listarUsuario("");
            for (int i = 0; i <lista.size(); i++) {
                 if(i==se){
                    String id=lista.get(i).getId_usuario()+"";
                    String nom=lista.get(i).getNombre()+"";
                    String pass=lista.get(i).getContrasena()+"";
                    String permiso=lista.get(i).getPermisos()+"";
                    int yu=0;
                    if("Gerente".equalsIgnoreCase(permiso)){
                        yu=2;
                    }else{
                        if("Administrador".equalsIgnoreCase(permiso)){
                            yu=1;
                        }else{
                            if("Cajero".equalsIgnoreCase(permiso)){
                                yu=3;
                            }else{
                                if("Jefe de Seccion".equalsIgnoreCase(permiso)){
                                    yu=4;
                                }
                            }
                        }
                    }
                    Image img=lista.get(i).getFoto();
                    ImageIcon icon=null;
                    if(img!=null){
                        Image nimg = img.getScaledInstance(100, 100, Image.SCALE_SMOOTH);
                        icon= new ImageIcon(nimg);
                    }else{
                        icon=null;
                    }
                    vista.getTxtid().setText(id);
                    vista.getTxtnom().setText(nom);
                    vista.getTxtpass().setText(pass);
                    vista.getJcbxpermiso().setSelectedIndex(yu);
                    vista.getJlbfoto().setIcon(icon);
                 }
            }
         }else{
            JOptionPane.showMessageDialog(vista, "Seleccione una fila");
            vista.getJdgEditarcrear().setVisible(false);
        }
    }
    
    private void limpiar(){
        vista.getTxtid().setText("");
        vista.getTxtnom().setText("");
        vista.getTxtpass().setText("");
        vista.getJcbxpermiso().setSelectedIndex(0);
        vista.getJlbfoto().setIcon(null);
    }  
    
    private void eliminar_u(){
        int se=vista.getJtuser().getSelectedRow();
        if (se>=0){
            cargarLista("");
            List<Usuario> lista=modelo.listarUser();
            for (int i = 0; i <lista.size(); i++) {
                 if(i==se){
                    vista.getTxtidel2().setText(lista.get(i).getId_usuario()+"");
                    vista.getTxtnomdel().setText(lista.get(i).getNombre()+" "+lista.get(i).getPermisos());
                 }
            }
        }else{
             JOptionPane.showMessageDialog(vista, "Seleccione una fila");
            vista.getJdgeliminar().setVisible(false);
        }
    }
    
    private void confirmar(){
        String id=vista.getTxtidel2().getText();
        Modelo_Usuario u=new Modelo_Usuario();
        u.setId_usuario(id);
        if(u.eliminar()){
            JOptionPane.showMessageDialog(vista, "Persona Eliminada Satisfactoriamente");
            vista.getJdgeliminar().dispose();
            limpiar();
        }
    }
    
}
