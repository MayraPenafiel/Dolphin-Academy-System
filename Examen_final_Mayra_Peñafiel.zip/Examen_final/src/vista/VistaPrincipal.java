/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

/**
 *
 * @author MayraPeñafiel
 */
public class VistaPrincipal extends javax.swing.JFrame {

    /**
     * Creates new form VistaPrincipal
     */
    
    public VistaPrincipal() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToolBar1 = new javax.swing.JToolBar();
        jbCrudUsuario = new javax.swing.JButton();
        jSeparator2 = new javax.swing.JToolBar.Separator();
        jdskprincipal = new javax.swing.JDesktopPane();
        jLabel1 = new javax.swing.JLabel();
        jlbmensaje = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        MenuUsuario = new javax.swing.JMenu();
        MenuCrudUsuarios = new javax.swing.JMenuItem();
        MenuUsuariosReporte = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        MenuPersonasSalir = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jToolBar1.setBackground(new java.awt.Color(255, 255, 255));
        jToolBar1.setRollover(true);

        jbCrudUsuario.setBackground(new java.awt.Color(255, 255, 255));
        jbCrudUsuario.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/icons/User.png"))); // NOI18N
        jbCrudUsuario.setToolTipText("Mantenimiento de Personas");
        jbCrudUsuario.setFocusable(false);
        jbCrudUsuario.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbCrudUsuario.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jbCrudUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbCrudUsuarioActionPerformed(evt);
            }
        });
        jToolBar1.add(jbCrudUsuario);
        jToolBar1.add(jSeparator2);

        jdskprincipal.setBackground(new java.awt.Color(0, 0, 0));

        jdskprincipal.setLayer(jLabel1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jdskprincipalLayout = new javax.swing.GroupLayout(jdskprincipal);
        jdskprincipal.setLayout(jdskprincipalLayout);
        jdskprincipalLayout.setHorizontalGroup(
            jdskprincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jdskprincipalLayout.createSequentialGroup()
                .addContainerGap(343, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(149, 149, 149))
        );
        jdskprincipalLayout.setVerticalGroup(
            jdskprincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jdskprincipalLayout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35))
        );

        jlbmensaje.setText("Sistema Ventanas 1.0");

        MenuUsuario.setText("Usuarios");

        MenuCrudUsuarios.setText("Crud Usuarios");
        MenuUsuario.add(MenuCrudUsuarios);

        MenuUsuariosReporte.setText("Reporte Usuarios");
        MenuUsuariosReporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuUsuariosReporteActionPerformed(evt);
            }
        });
        MenuUsuario.add(MenuUsuariosReporte);
        MenuUsuario.add(jSeparator1);

        MenuPersonasSalir.setText("Salir");
        MenuPersonasSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MenuPersonasSalirActionPerformed(evt);
            }
        });
        MenuUsuario.add(MenuPersonasSalir);

        jMenuBar1.add(MenuUsuario);

        jMenu2.setText("Edit");
        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jToolBar1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jlbmensaje)
                    .addComponent(jdskprincipal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jdskprincipal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jlbmensaje)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void MenuUsuariosReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuUsuariosReporteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MenuUsuariosReporteActionPerformed

    private void MenuPersonasSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MenuPersonasSalirActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_MenuPersonasSalirActionPerformed

    private void jbCrudUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbCrudUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jbCrudUsuarioActionPerformed

    public JMenuItem getMenuCrudUsuarios() {
        return MenuCrudUsuarios;
    }
    public void setMenuCrudUsuarios(JMenuItem MenuCrudUsuarios) {
        this.MenuCrudUsuarios = MenuCrudUsuarios;
    }
    public JMenuItem getMenuPersonasSalir() {
        return MenuPersonasSalir;
    }
    public void setMenuPersonasSalir(JMenuItem MenuPersonasSalir) {
        this.MenuPersonasSalir = MenuPersonasSalir;
    }
    public JMenu getMenuUsuario() {
        return MenuUsuario;
    }
    public void setMenuUsuario(JMenu MenuUsuario) {
        this.MenuUsuario = MenuUsuario;
    }
    public JMenuItem getMenuUsuariosReporte() {
        return MenuUsuariosReporte;
    }
    public void setMenuUsuariosReporte(JMenuItem MenuUsuariosReporte) {
        this.MenuUsuariosReporte = MenuUsuariosReporte;
    }
    public JButton getJbCrudUsuario() {
        return jbCrudUsuario;
    }
    public void setJbCrudUsuario(JButton jbCrudUsuario) {
        this.jbCrudUsuario = jbCrudUsuario;
    }
    public JDesktopPane getJdskprincipal() {
        return jdskprincipal;
    }
    public void setJdskprincipal(JDesktopPane jdskprincipal) {
        this.jdskprincipal = jdskprincipal;
    }
    public JLabel getJlbmensaje() {
        return jlbmensaje;
    }
    public void setJlbmensaje(JLabel jlbmensaje) {
        this.jlbmensaje = jlbmensaje;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem MenuCrudUsuarios;
    private javax.swing.JMenuItem MenuPersonasSalir;
    private javax.swing.JMenu MenuUsuario;
    private javax.swing.JMenuItem MenuUsuariosReporte;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JToolBar.Separator jSeparator2;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JButton jbCrudUsuario;
    private javax.swing.JDesktopPane jdskprincipal;
    private javax.swing.JLabel jlbmensaje;
    // End of variables declaration//GEN-END:variables
}
