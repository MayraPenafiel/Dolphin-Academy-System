/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextField;

/**
 *
 * @author Mayra Peñafiel
 */

public class vistaUsuario extends javax.swing.JInternalFrame {

    /**
     * Creates new form vistaUsuario
     */
    
    public vistaUsuario() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jdgEditarcrear = new javax.swing.JDialog();
        JPanel = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jlbtitulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtpass = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtnom = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtid = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jcbxpermiso = new javax.swing.JComboBox<>();
        jlbfoto = new javax.swing.JLabel();
        jbexaminar = new javax.swing.JButton();
        jbguardar = new javax.swing.JButton();
        jbcancelar = new javax.swing.JButton();
        jdgeliminar = new javax.swing.JDialog();
        jPanel5 = new javax.swing.JPanel();
        lbtitutolo2 = new javax.swing.JLabel();
        jbconfirmar2 = new javax.swing.JButton();
        Txtidel2 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jbcancelardel = new javax.swing.JButton();
        txtnomdel = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jlbuser = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtuser = new javax.swing.JTable();
        jtxtbuscar = new javax.swing.JTextField();
        jbadd = new javax.swing.JButton();
        jbact = new javax.swing.JButton();
        jbdelete = new javax.swing.JButton();
        jbedit = new javax.swing.JButton();
        jbprintuser = new javax.swing.JButton();
        jbsalir = new javax.swing.JButton();

        JPanel.setBackground(new java.awt.Color(255, 255, 255));
        JPanel.setForeground(new java.awt.Color(255, 255, 255));

        jPanel4.setBackground(new java.awt.Color(204, 204, 255));

        jlbtitulo.setFont(new java.awt.Font("Andalus", 3, 14)); // NOI18N
        jlbtitulo.setForeground(new java.awt.Color(0, 102, 102));
        jlbtitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jlbtitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jlbtitulo, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
        );

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setText("Id:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel3.setText("Nombre Corto:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel4.setText("Contraseña:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel5.setText("Permisos:");

        jcbxpermiso.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Administrador", "Gerente", "Cajero", "Jefe de Seccion" }));

        jlbfoto.setBackground(new java.awt.Color(255, 255, 255));
        jlbfoto.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jbexaminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/icons/Search-icon (1).png"))); // NOI18N
        jbexaminar.setText("Examinar");

        jbguardar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/icons/Actions-document-save-icon (16).png"))); // NOI18N
        jbguardar.setText("Guardar");

        jbcancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/icons/Actions-edit-delete-icon (1).png"))); // NOI18N
        jbcancelar.setText("Cancelar");

        javax.swing.GroupLayout JPanelLayout = new javax.swing.GroupLayout(JPanel);
        JPanel.setLayout(JPanelLayout);
        JPanelLayout.setHorizontalGroup(
            JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPanelLayout.createSequentialGroup()
                .addGroup(JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JPanelLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jbexaminar, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jlbfoto, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(64, 64, 64)
                        .addGroup(JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3)
                            .addGroup(JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtpass, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jcbxpermiso, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtnom, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(JPanelLayout.createSequentialGroup()
                        .addGap(128, 128, 128)
                        .addComponent(jbguardar)
                        .addGap(18, 18, 18)
                        .addComponent(jbcancelar)))
                .addContainerGap(56, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        JPanelLayout.setVerticalGroup(
            JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(JPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 17, Short.MAX_VALUE)
                .addGroup(JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jlbfoto, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, JPanelLayout.createSequentialGroup()
                        .addGroup(JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtnom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(21, 21, 21)
                        .addGroup(JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtpass, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(21, 21, 21)))
                .addGroup(JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jcbxpermiso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(JPanelLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jbexaminar)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addGroup(JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jbguardar)
                    .addComponent(jbcancelar))
                .addGap(31, 31, 31))
        );

        javax.swing.GroupLayout jdgEditarcrearLayout = new javax.swing.GroupLayout(jdgEditarcrear.getContentPane());
        jdgEditarcrear.getContentPane().setLayout(jdgEditarcrearLayout);
        jdgEditarcrearLayout.setHorizontalGroup(
            jdgEditarcrearLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jdgEditarcrearLayout.setVerticalGroup(
            jdgEditarcrearLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(JPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setToolTipText("");

        lbtitutolo2.setBackground(new java.awt.Color(0, 102, 102));
        lbtitutolo2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        lbtitutolo2.setForeground(new java.awt.Color(0, 102, 102));
        lbtitutolo2.setText("¿Seguro/a que desea Eliminar El Usuario Seleccionado?");

        jbconfirmar2.setBackground(new java.awt.Color(255, 255, 255));
        jbconfirmar2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jbconfirmar2.setForeground(new java.awt.Color(0, 153, 153));
        jbconfirmar2.setText("Confirmar");

        Txtidel2.setEditable(false);
        Txtidel2.setBackground(new java.awt.Color(255, 255, 255));
        Txtidel2.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel22.setForeground(new java.awt.Color(0, 102, 102));
        jLabel22.setText("ID:");

        jLabel23.setBackground(new java.awt.Color(204, 204, 255));
        jLabel23.setForeground(new java.awt.Color(0, 102, 102));
        jLabel23.setText("Nombre:");

        jbcancelardel.setBackground(new java.awt.Color(255, 255, 255));
        jbcancelardel.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jbcancelardel.setForeground(new java.awt.Color(0, 153, 153));
        jbcancelardel.setText("Cancelar");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel23)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jbconfirmar2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jbcancelardel)
                                .addGap(43, 43, 43))))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(lbtitutolo2))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(88, 88, 88)
                        .addComponent(jLabel22)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtnomdel)
                            .addComponent(Txtidel2, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE))))
                .addContainerGap(37, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addComponent(lbtitutolo2)
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(Txtidel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(txtnomdel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jbconfirmar2)
                    .addComponent(jbcancelardel))
                .addGap(31, 31, 31))
        );

        javax.swing.GroupLayout jdgeliminarLayout = new javax.swing.GroupLayout(jdgeliminar.getContentPane());
        jdgeliminar.getContentPane().setLayout(jdgeliminarLayout);
        jdgeliminarLayout.setHorizontalGroup(
            jdgeliminarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jdgeliminarLayout.setVerticalGroup(
            jdgeliminarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 102, 102));

        jlbuser.setFont(new java.awt.Font("Andalus", 2, 14)); // NOI18N
        jlbuser.setForeground(new java.awt.Color(255, 255, 255));
        jlbuser.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        jlbuser.setText("Buscar");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 11)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/icons/Apps-system-users-icon.png"))); // NOI18N
        jLabel1.setText("Usuarios");
        jLabel1.setToolTipText("");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1)
        );

        jtuser.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Id", "Nombre", "Permisos", "Foto"
            }
        ));
        jScrollPane1.setViewportView(jtuser);

        jbadd.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jbadd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/icons/Actions-bookmark-add-icon.png"))); // NOI18N
        jbadd.setText("Crear");

        jbact.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jbact.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/icons/Actions-mail-mark-task-icon.png"))); // NOI18N
        jbact.setText("Actualizar");

        jbdelete.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jbdelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/icons/Actions-document-close-icon.png"))); // NOI18N
        jbdelete.setText("Eliminar");

        jbedit.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jbedit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/icons/Actions-document-edit-icon.png"))); // NOI18N
        jbedit.setText("Editar");

        jbprintuser.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jbprintuser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/icons/Actions-document-print-icon.png"))); // NOI18N
        jbprintuser.setText("Imprimir");

        jbsalir.setBackground(new java.awt.Color(0, 102, 102));
        jbsalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/vista/icons/Signpost.png"))); // NOI18N
        jbsalir.setToolTipText("regresar");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jlbuser)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jtxtbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jbadd)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jbact, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jbedit, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jbdelete)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                        .addComponent(jbprintuser, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jbsalir, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jlbuser)
                    .addComponent(jtxtbuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jbadd)
                    .addComponent(jbact)
                    .addComponent(jbdelete)
                    .addComponent(jbedit)
                    .addComponent(jbprintuser))
                .addGap(28, 28, 28)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jbsalir, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    //Metodos getter y setter
    
    //Frame/Vista Principal
    public JButton getJbact() {
        return jbact;
    }
    public void setJbact(JButton jbact) {
        this.jbact = jbact;
    }
    public JButton getJbadd() {
        return jbadd;
    }
    public void setJbadd(JButton jbadd) {
        this.jbadd = jbadd;
    }

    public JButton getJbdelete() {
        return jbdelete;
    }

    public void setJbdelete(JButton jbdelete) {
        this.jbdelete = jbdelete;
    }

    public JButton getJbedit() {
        return jbedit;
    }

    public void setJbedit(JButton jbedit) {
        this.jbedit = jbedit;
    }

    public JButton getJbprintuser() {
        return jbprintuser;
    }

    public void setJbprintuser(JButton jbprintuser) {
        this.jbprintuser = jbprintuser;
    }

    public JButton getJbsalir() {
        return jbsalir;
    }

    public void setJbsalir(JButton jbsalir) {
        this.jbsalir = jbsalir;
    }

    public JComboBox<String> getJcbxpermiso() {
        return jcbxpermiso;
    }

    public void setJcbxpermiso(JComboBox<String> jcbxpermiso) {
        this.jcbxpermiso = jcbxpermiso;
    }

    public JTextField getJtxtbuscar() {
        return jtxtbuscar;
    }

    public void setJtxtbuscar(JTextField jtxtbuscar) {
        this.jtxtbuscar = jtxtbuscar;
    }
    public JTable getJtuser() {
        return jtuser;
    }
    public void setJtuser(JTable jtuser) {
        this.jtuser = jtuser;
    }

    //Vista Ingresar/Modificar
    public JButton getJbcancelar() {
        return jbcancelar;
    }
    public void setJbcancelar(JButton jbcancelar) {
        this.jbcancelar = jbcancelar;
    }
    public JButton getJbexaminar() {
        return jbexaminar;
    }
    public void setJbexaminar(JButton jbexaminar) {
        this.jbexaminar = jbexaminar;
    }
    public JButton getJbguardar() {
        return jbguardar;
    }
    public void setJbguardar(JButton jbguardar) {
        this.jbguardar = jbguardar;
    }
    public JDialog getJdgEditarcrear() {
        return jdgEditarcrear;
    }
    public void setJdgEditarcrear(JDialog jdgEditarcrear) {
        this.jdgEditarcrear = jdgEditarcrear;
    }
    public JLabel getJlbfoto() {
        return jlbfoto;
    }
    public void setJlbfoto(JLabel jlbfoto) {
        this.jlbfoto = jlbfoto;
    }
    public JLabel getJlbtitulo() {
        return jlbtitulo;
    }
    public void setJlbtitulo(JLabel jlbtitulo) {
        this.jlbtitulo = jlbtitulo;
    }
    public JLabel getJlbuser() {
        return jlbuser;
    }
    public void setJlbuser(JLabel jlbuser) {
        this.jlbuser = jlbuser;
    }
    public JTextField getTxtid() {
        return txtpass;
    }
    public void setTxtid(JTextField txtid) {
        this.txtpass = txtid;
    }
    public JTextField getTxtpass() {
        return txtpass;
    }
    public void setTxtpass(JTextField txtpass) {
        this.txtpass = txtpass;
    }

    //Vista Eliminar
    public JTextField getTxtidel2() {
        return Txtidel2;
    }
    public void setTxtidel2(JTextField Txtidel2) {
        this.Txtidel2 = Txtidel2;
    }
    public JButton getJbcancelardel() {
        return jbcancelardel;
    }
    public void setJbcancelardel(JButton jbcancelardel) {
        this.jbcancelardel = jbcancelardel;
    }
    public JButton getJbconfirmar2() {
        return jbconfirmar2;
    }
    public void setJbconfirmar2(JButton jbconfirmar2) {
        this.jbconfirmar2 = jbconfirmar2;
    }
    public JLabel getLbtitutolo2() {
        return lbtitutolo2;
    }
    public void setLbtitutolo2(JLabel lbtitutolo2) {
        this.lbtitutolo2 = lbtitutolo2;
    }
    public JTextField getTxtnom() {
        return txtnom;
    }
    public void setTxtnom(JTextField txtnom) {
        this.txtnom = txtnom;
    }
    public JTextField getTxtnomdel() {
        return txtnomdel;
    }
    public void setTxtnomdel(JTextField txtnomdel) {
        this.txtnomdel = txtnomdel;
    }
    public JDialog getJdgeliminar() {
        return jdgeliminar;
    }
    public void setJdgeliminar(JDialog jdgeliminar) {
        this.jdgeliminar = jdgeliminar;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel JPanel;
    private javax.swing.JTextField Txtidel2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton jbact;
    private javax.swing.JButton jbadd;
    private javax.swing.JButton jbcancelar;
    private javax.swing.JButton jbcancelardel;
    private javax.swing.JButton jbconfirmar2;
    private javax.swing.JButton jbdelete;
    private javax.swing.JButton jbedit;
    private javax.swing.JButton jbexaminar;
    private javax.swing.JButton jbguardar;
    private javax.swing.JButton jbprintuser;
    private javax.swing.JButton jbsalir;
    private javax.swing.JComboBox<String> jcbxpermiso;
    private javax.swing.JDialog jdgEditarcrear;
    private javax.swing.JDialog jdgeliminar;
    private javax.swing.JLabel jlbfoto;
    private javax.swing.JLabel jlbtitulo;
    private javax.swing.JLabel jlbuser;
    private javax.swing.JTable jtuser;
    private javax.swing.JTextField jtxtbuscar;
    private javax.swing.JLabel lbtitutolo2;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtnom;
    private javax.swing.JTextField txtnomdel;
    private javax.swing.JTextField txtpass;
    // End of variables declaration//GEN-END:variables
}
