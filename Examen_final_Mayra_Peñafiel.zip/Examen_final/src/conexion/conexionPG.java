/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Mayra Peñafiel
 */

public class conexionPG {
    private Connection con;
    private Statement st;
    private ResultSet rs;
    
    //Datos de su conexion local:
    private String cadenaConexion="jdbc:postgresql://localhost:5432/supermercado";
    private String usuarioPG="postgres";
    private String contrasPG="1234x";

    public conexionPG() {
        try {
            Class.forName("org.postgresql.Driver");
        } catch (ClassNotFoundException ex) {
            //No encontramos driver
            Logger.getLogger(conexionPG.class.getName()).log(Level.SEVERE, null, ex);
        }
        try {
           con= DriverManager.getConnection(cadenaConexion, usuarioPG, contrasPG);
        } catch (SQLException ex) {
            Logger.getLogger(conexionPG.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public ResultSet consulta(String sqlc){
    
        try {
            st= con.createStatement();
            ResultSet rs=st.executeQuery(sqlc);
            return rs;
        } catch (SQLException ex) {
            Logger.getLogger(conexionPG.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public boolean accion(String sqla){
        try {
            st=con.createStatement();
            boolean rb=st.execute(sqla);
            st.close();
            return true; //rb;
        } catch (SQLException ex) {
            Logger.getLogger(conexionPG.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    public Connection getCon() {
        return con;
    }

    public void setCon(Connection con) {
        this.con = con;
    }
}
