/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.awt.Image;

/**
 *
 * @author Mayra Peñafiel
 */

public class Usuario {
    
    //Atribuos
    private String Id_usuario;
    private String Nombre;
    private String Contrasena;
    private String Permisos;
    private Image foto;
    
    //Constructores
    public Usuario(String Id_usuario, String Nombre, String Contrasena, String Permisos, Image foto) {
        this.Id_usuario = Id_usuario;
        this.Nombre = Nombre;
        this.Contrasena = Contrasena;
        this.Permisos = Permisos;
        this.foto = foto;
    }
    public Usuario() {
    }
    
    //Metodos getter y setter
    public String getId_usuario() {
        return Id_usuario;
    }
    public void setId_usuario(String Id_usuario) {
        this.Id_usuario = Id_usuario;
    }
    public String getNombre() {
        return Nombre;
    }
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    public String getContrasena() {
        return Contrasena;
    }
    public void setContrasena(String Contrasena) {
        this.Contrasena = Contrasena;
    }
    public Image getFoto() {
        return foto;
    }
    public void setFoto(Image foto) {
        this.foto = foto;
    }
    public String getPermisos() {
        return Permisos;
    }
    public void setPermisos(String Permisos) {
        this.Permisos = Permisos;
    }
    
    //Metodo toString
    @Override
    public String toString() {
        return "Usuario{" + "Id_usuario=" + Id_usuario + ", Nombre=" + Nombre + ", Contrasena=" + Contrasena + ", Permisos=" + Permisos + ", foto=" + foto + '}';
    }
    
}
