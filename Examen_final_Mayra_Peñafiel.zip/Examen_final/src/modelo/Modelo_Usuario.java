/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import conexion.conexionPG;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import org.postgresql.util.Base64;

/**
 *
 * @author Mayra Peñafiel
 */

public class Modelo_Usuario extends Usuario{
    
    //Atributos
    private conexionPG con=new conexionPG();
    
    //Constructores
    public Modelo_Usuario(String Id_usuario, String Nombre, String Contrasena, String Permisos, Image foto) {
        super(Id_usuario, Nombre, Contrasena, Permisos, foto);
    }
    public Modelo_Usuario() {
    }
    
    //Metodo Cargar Usuarios
    public List <Usuario> listarUser (){
       String sql = "select * from usuarios";
       ResultSet rs= con.consulta(sql);
       List<Usuario> lista=new ArrayList<>();
       try {
           while(rs.next()){
               Usuario u= new Usuario();
               u.setId_usuario(rs.getString("id_usuario"));//campos de la BD
               u.setNombre(rs.getString("nombre_corto"));//campos de la BD
               u.setContrasena(rs.getString("contrasena"));//campos de la BD
               u.setPermisos(rs.getString("permisos"));
             
               //Obtener Foto
               byte[] bf;
               bf=rs.getBytes("foto");
               if(bf!=null){
                   bf=Base64.decode(bf,0,bf.length);
                   try {
                        u.setFoto(obtenerImagen(bf));
                    } catch (IOException ex) {
                        Logger.getLogger(Modelo_Usuario.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
               lista.add(u);
           }
           rs.close();
           return lista;
       } catch (SQLException ex) {
           Logger.getLogger(Modelo_Usuario.class.getName()).log(Level.SEVERE, null, ex);
           return null;
       }
    }
    
    //Metodo Buscar Personas
    public List <Usuario> listarUsuario (String aguja){
       String sql = "select * from usuarios WHERE ";
       sql+=" UPPER(nombre_corto) like UPPER('%"+aguja+"%') OR ";
       sql+=" UPPER(permisos) like UPPER('%"+aguja+"%') OR ";
       sql+=" UPPER(id_usuario) like UPPER('%"+aguja+"%') ";
       ResultSet rs= con.consulta(sql);
       List<Usuario> lista=new ArrayList<Usuario>();
       try {
           byte[] bf;
           while(rs.next()){
               Modelo_Usuario mu=new  Modelo_Usuario();
               mu.setId_usuario(rs.getString("id_usuario"));//campos de la BD
               mu.setNombre(rs.getString("nombre_corto"));//campos de la BD
               mu.setContrasena(rs.getString("contrasena"));//campos de la BD
               mu.setPermisos(rs.getString("permisos"));
             //Foto
              bf=rs.getBytes("foto");
                if(bf!=null){
                    bf=Base64.decode(bf,0,bf.length);
                    try {
                        mu.setFoto(obtenerImagen(bf));
                    } catch (IOException ex) {
                        Logger.getLogger(Modelo_Usuario.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
             lista.add(mu);
           }
           rs.close();
           return lista;
       } catch (SQLException ex) {
           Logger.getLogger(Modelo_Usuario.class.getName()).log(Level.SEVERE, null, ex);
           return null;
       }
    }
    
    //Metodo para convertir Bytes a Imagen
    public Image obtenerImagen(byte[] bytes ) throws IOException{
        ByteArrayInputStream bis= new ByteArrayInputStream(bytes);
        Iterator it= ImageIO.getImageReadersByFormatName("png");
        ImageReader reader=(ImageReader)it.next();
        Object source=bis;
        ImageInputStream iis=ImageIO.createImageInputStream(source);
        reader.setInput(iis,true);
        ImageReadParam param= reader.getDefaultReadParam();
        param.setSourceSubsampling(1, 1, 0, 0);
        return reader.read(0,param);
    }
    
    //Metodo para guardar
    public boolean grabar(){
        String foto64 = null;
        try {
           BufferedImage img=imgBimage(getFoto());
           ByteArrayOutputStream bos=new ByteArrayOutputStream();
           ImageIO.write(img,"PNG",bos);
           byte[] imgb=bos.toByteArray();
           foto64=Base64.encodeBytes(imgb);
       } catch (IOException ex) {
           Logger.getLogger(Modelo_Usuario.class.getName()).log(Level.SEVERE, null, ex);
       }
       String sql;
           sql="INSERT INTO usuarios(id_usuario,nombre_corto,contrasena,permisos,foto) ";
           sql+=" VALUES ('"+getId_usuario()+"','"+getNombre()+"','"+getContrasena()+"','"
                   +getPermisos()+"','"+foto64+"') ";
       return con.accion(sql);
    }
    
    //Fucion para convertir el formato de binario a imagen
    private BufferedImage imgBimage(Image img){
        if (img instanceof BufferedImage){
            return (BufferedImage)img;
        }
        BufferedImage bi = new BufferedImage(
                img.getWidth(null),img.getHeight(null),BufferedImage.TYPE_INT_ARGB
        );
        Graphics2D bGR = bi.createGraphics();
        bGR.drawImage(img, 0, 0,null);//Medir el tamaño de la imagen
        bGR.dispose();
        return bi;        
    }
        
    //Metodo Modificar
    public boolean modificar(){
        String foto64 = null;
        try {
           BufferedImage img=imgBimage(getFoto());
           ByteArrayOutputStream bos=new ByteArrayOutputStream();
           ImageIO.write(img,"PNG",bos);
           byte[] imgb=bos.toByteArray();
           foto64=Base64.encodeBytes(imgb);
       } catch (IOException ex) {
           Logger.getLogger(Modelo_Usuario.class.getName()).log(Level.SEVERE, null, ex);
       }
        String sql;
        sql="UPDATE usuarios ";
        sql+=" SET nombre_corto = '"+getNombre()+"'"+", contrasena = '"+getContrasena()+"'"+", permisos = '"
                +getPermisos()+"'"+", foto = '"+foto64+"'";
        sql+=" WHERE id_usuario = '"+getId_usuario()+"' ";
       return con.accion(sql);
    }
    
    //Metodo para eliminar
    public boolean eliminar(){
        String sql;
        sql= "DELETE FROM usuarios ";
        sql+=" WHERE id_usuario = '"+getId_usuario()+"' ";
        return con.accion(sql);
    }
    
}
